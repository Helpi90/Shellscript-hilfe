#!/bin/bash

echo Hallo $1 $2
echo Ihr Vorname hat ${#1} Zeichen.
echo Ihr Nachname hat ${#2} Zeichen.
echo Anzahl der Argument ist $#

