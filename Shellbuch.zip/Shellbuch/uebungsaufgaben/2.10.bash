hund
katze
maus
löwe
tieger
affe
